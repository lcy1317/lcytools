def fileList():
    print("emailMe:发送邮件")
    print("qqmessage:通过QQ推送消息")